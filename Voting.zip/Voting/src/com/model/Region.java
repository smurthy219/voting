package com.model;

public class Region {
	private String rgnName ;
	private String contestants;
	
	
	public String getRgnName() {
		return rgnName;
	}
	public void setRgnName(String rgnName) {
		this.rgnName = rgnName;
	}
	public String getContestants() {
		return contestants;
	}
	public void setContestants(String contestants) {
		this.contestants = contestants;
	}
}
